<p align="center"><img src="assets/hartzcraft/textures/logo.png" \></p>

# Server Resource Pack
Bereitgestellt von [puyomi2k](https://github.com/puyomi2k) und [UniDoku](https://github.com/unidoku).

## Drittanbieter-Resourcen
Dieses Pack beinhaltet Inhalte von "[Jake's Build Tools](https://github.com/maybejake/Jakes-Build-Tools)", damit diese mit auf den HartzCraft-Server geladen werden können.
