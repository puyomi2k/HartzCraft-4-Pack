![](assets/hartzcraft/textures/logo.png)
# Server Resource Pack
Bereitgestellt von @puyomi2k und @unidoku

## Disclaimer
Dieses Pack beinhaltet Inhalte von "[Jake's Build Tools](https://github.com/maybejake/Jakes-Build-Tools)", damit diese mit auf den HartzCraft-Server geladen werden können
